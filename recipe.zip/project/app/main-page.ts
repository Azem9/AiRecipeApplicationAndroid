import { EventData, Page } from '@nativescript/core';
import { RecipeViewModel } from './view-models/recipe-view-model';

export function navigatingTo(args: EventData) {
    const page = <Page>args.object;
    page.bindingContext = new RecipeViewModel();
}