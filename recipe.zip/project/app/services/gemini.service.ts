import { GoogleGenerativeAI } from '@google/generative-ai';

export class GeminiService {
    private genAI: GoogleGenerativeAI;
    private model: any;

    constructor() {
        this.genAI = new GoogleGenerativeAI('AIzaSyCEdYi78NeVxMbTT7gXvngqpLlMXtbQ9N8');
        this.model = this.genAI.getGenerativeModel({ model: 'gemini-pro' });
    }

    async getRecipe(input: string): Promise<string> {
        try {
            const prompt = `Lütfen şu malzeme veya yemek için detaylı bir Türkçe tarif ver: ${input}. 
                          Tarifi şu formatta ver:
                          - Malzemeler
                          - Hazırlanış
                          - Püf Noktaları`;
            
            const result = await this.model.generateContent(prompt);
            const response = await result.response;
            return response.text();
        } catch (error) {
            console.error('Tarif alınırken hata:', error);
            return 'Üzgünüm, tarif alınırken bir hata oluştu.';
        }
    }
}