import { Observable } from '@nativescript/core';
import { GeminiService } from '../services/gemini.service';

export class RecipeViewModel extends Observable {
    private geminiService: GeminiService;
    private _searchText: string = '';
    private _recipe: string = '';
    private _isLoading: boolean = false;

    constructor() {
        super();
        this.geminiService = new GeminiService();
    }

    get searchText(): string {
        return this._searchText;
    }

    set searchText(value: string) {
        if (this._searchText !== value) {
            this._searchText = value;
            this.notifyPropertyChange('searchText', value);
        }
    }

    get recipe(): string {
        return this._recipe;
    }

    set recipe(value: string) {
        if (this._recipe !== value) {
            this._recipe = value;
            this.notifyPropertyChange('recipe', value);
        }
    }

    get isLoading(): boolean {
        return this._isLoading;
    }

    set isLoading(value: boolean) {
        if (this._isLoading !== value) {
            this._isLoading = value;
            this.notifyPropertyChange('isLoading', value);
        }
    }

    async searchRecipe() {
        if (!this.searchText.trim()) return;

        this.isLoading = true;
        try {
            const result = await this.geminiService.getRecipe(this.searchText);
            this.recipe = result;
        } catch (error) {
            console.error('Arama hatası:', error);
            this.recipe = 'Tarif aranırken bir hata oluştu.';
        } finally {
            this.isLoading = false;
        }
    }
}